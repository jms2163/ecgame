// --------------------------------------------------
// DevConsole.js
// Development-only console access to game systems
// --------------------------------------------------

import GameStateManager
    from "./GameStateManager.js";
import ZoneManager from "./ZoneManager.js";
import NavigationUI from "./NavigationUI.js";
import ZoneCatalog from "./ZoneCatalog.js";
import ZoneStatusResolver
    from "./ZoneStatusResolver.js";
import SaveManager from "./SaveManager.js";
import PondWorld from "./PondWorld.js";
import PondController from "./PondController.js";
import PondPerception from "./PondPerception.js";
import PondWorldGenerator
    from "./PondWorldGenerator.js";
import SeededRandom from "./SeededRandom.js";
import PondWorldConfig
    from "./PondWorldConfig.js";
import ResourceManager
    from "./ResourceManager.js";
import XPManager from "./XPManager.js";
import ParticleInventoryManager
    from "./ParticleInventoryManager.js";
import SubatomicAssemblyManager
    from "./SubatomicAssemblyManager.js";
import SubatomicAssemblyUI
    from "./SubatomicAssemblyUI.js";
import QuantumZone from "./QuantumZone.js";
import QuantumField from "./QuantumField.js";
import ResearchManager
    from "./ResearchManager.js";
import CellSystemManager
    from "./CellSystemManager.js";
import OrganelleView
    from "./OrganelleView.js";
import OrganelleExperimentStage
    from "./OrganelleExperimentStage.js";
import OrganelleExperimentSubmissionManager
    from "./OrganelleExperimentSubmissionManager.js";
import ExperimentPlacementEvaluator
    from "./ExperimentPlacementEvaluator.js";
import OrganelleExperimentLibrary
    from "./OrganelleExperimentLibrary.js";

const DevConsole = {

    initialize() {

        window.ECGame = {
            GameStateManager,
            ZoneManager,
            NavigationUI,
            ZoneCatalog,
            ZoneStatusResolver,
            SaveManager,
            PondWorld,
            PondController,
            PondPerception,
            PondWorldGenerator,
            SeededRandom,
            PondWorldConfig,
            ResourceManager,
            XPManager,
            ParticleInventoryManager,
            SubatomicAssemblyManager,
            SubatomicAssemblyUI,
            QuantumZone,
            QuantumField,
            ResearchManager,
            CellSystemManager,
            OrganelleView,
            OrganelleExperimentStage,
            OrganelleExperimentSubmissionManager,
            ExperimentPlacementEvaluator,
            OrganelleExperimentLibrary
        };

        console.log(
            "DevConsole initialized. Use window.ECGame to access development tools."
        );

    }

};

export default DevConsole;
