// --------------------------------------------------
// QuantumField.js
// Lifecycle-safe animated particle field for q1
// --------------------------------------------------

const FIELD_WIDTH = 800;
const FIELD_HEIGHT = 420;
const PARTICLES_PER_TYPE = 3;

const PARTICLE_ORDER = Object.freeze([
    "proton",
    "neutron",
    "electron"
]);

const PARTICLE_STYLES = Object.freeze({
    proton: Object.freeze({
        symbol: "pâº",
        fill: "#ff5f70",
        stroke: "#ffd2d7",
        glow: "rgba(255, 95, 112, 0.72)",
        radius: 25
    }),

    neutron: Object.freeze({
        symbol: "nâ°",
        fill: "#a99ab8",
        stroke: "#f0e8f7",
        glow: "rgba(183, 167, 201, 0.62)",
        radius: 25
    }),

    electron: Object.freeze({
        symbol: "eâ»",
        fill: "#55cfff",
        stroke: "#d8f5ff",
        glow: "rgba(85, 207, 255, 0.72)",
        radius: 19
    })
});

class FieldParticle {

    constructor(
        particleId,
        fieldWidth,
        fieldHeight
    ) {

        const style =
            PARTICLE_STYLES[particleId];

        this.id =
            `${particleId}-${Date.now()}-${Math.random()}`;
        this.particleId = particleId;
        this.radius = style.radius;

        this.x =
            this.radius +
            Math.random() *
            (
                fieldWidth -
                this.radius * 2
            );

        this.y =
            this.radius + 34 +
            Math.random() *
            (
                fieldHeight -
                this.radius * 2 -
                52
            );

        const speed =
            0.35 +
            Math.random() * 0.45;

        const angle =
            Math.random() *
            Math.PI * 2;

        this.velocityX =
            Math.cos(angle) * speed;
        this.velocityY =
            Math.sin(angle) * speed;

        this.pulseOffset =
            Math.random() *
            Math.PI * 2;

    }

    update(fieldWidth, fieldHeight) {

        this.x += this.velocityX;
        this.y += this.velocityY;

        const topBoundary =
            this.radius + 28;

        if (
            this.x <= this.radius ||
            this.x >=
                fieldWidth - this.radius
        ) {
            this.velocityX *= -1;
            this.x = Math.max(
                this.radius,
                Math.min(
                    fieldWidth - this.radius,
                    this.x
                )
            );
        }

        if (
            this.y <= topBoundary ||
            this.y >=
                fieldHeight - this.radius
        ) {
            this.velocityY *= -1;
            this.y = Math.max(
                topBoundary,
                Math.min(
                    fieldHeight - this.radius,
                    this.y
                )
            );
        }

    }

    contains(x, y) {

        return Math.hypot(
            this.x - x,
            this.y - y
        ) <= this.radius + 10;

    }

    draw(context, timestampMs) {

        const style =
            PARTICLE_STYLES[
                this.particleId
            ];

        const pulse =
            1 +
            Math.sin(
                timestampMs / 420 +
                this.pulseOffset
            ) * 0.06;

        context.save();
        context.translate(
            this.x,
            this.y
        );
        context.scale(pulse, pulse);

        context.beginPath();
        context.arc(
            0,
            0,
            this.radius,
            0,
            Math.PI * 2
        );

        context.fillStyle = style.fill;
        context.strokeStyle = style.stroke;
        context.lineWidth = 2;
        context.shadowColor = style.glow;
        context.shadowBlur = 16;
        context.fill();
        context.stroke();

        context.shadowBlur = 0;
        context.fillStyle = "#08020f";
        context.font =
            "bold 14px monospace";
        context.textAlign = "center";
        context.textBaseline = "middle";
        context.fillText(
            style.symbol,
            0,
            1
        );

        context.restore();

    }

}

const QuantumField = {

    initialized: false,
    active: false,
    canvasElement: null,
    context: null,
    particles: [],
    animationFrameId: null,
    pointerHandler: null,
    onParticleSelected: null,
    onFieldMiss: null,
    getActivityStatus: null,

    initialize({
        canvasElement,
        onParticleSelected,
        onFieldMiss,
        getActivityStatus
    } = {}) {

        if (this.initialized) {
            this.onParticleSelected =
                onParticleSelected ??
                this.onParticleSelected;
            this.onFieldMiss =
                onFieldMiss ??
                this.onFieldMiss;
            this.getActivityStatus =
                getActivityStatus ??
                this.getActivityStatus;

            return true;
        }

        if (
            !canvasElement ||
            typeof canvasElement.getContext !==
                "function"
        ) {
            throw new Error(
                "QuantumField: a canvas element is required"
            );
        }

        if (
            typeof onParticleSelected !==
                "function" ||
            typeof getActivityStatus !==
                "function"
        ) {
            throw new Error(
                "QuantumField: selection and activity callbacks are required"
            );
        }

        const context =
            canvasElement.getContext("2d");

        if (!context) {
            throw new Error(
                "QuantumField: 2D canvas context is unavailable"
            );
        }

        this.canvasElement =
            canvasElement;
        this.context = context;
        this.onParticleSelected =
            onParticleSelected;
        this.onFieldMiss =
            typeof onFieldMiss === "function"
                ? onFieldMiss
                : null;
        this.getActivityStatus =
            getActivityStatus;

        this.canvasElement.width =
            FIELD_WIDTH;
        this.canvasElement.height =
            FIELD_HEIGHT;

        this.pointerHandler =
            event =>
                this.handlePointer(event);

        this.canvasElement.addEventListener(
            "pointerdown",
            this.pointerHandler
        );

        this.initialized = true;

        this.ensurePopulation();
        this.drawFrame(0);

        console.log(
            "QuantumField.initialize() called"
        );

        return true;

    },

    isActivityCompleted() {

        return Boolean(
            this.getActivityStatus?.()
                ?.completed
        );

    },

    ensurePopulation() {

        if (
            !this.initialized ||
            this.isActivityCompleted()
        ) {
            return;
        }

        PARTICLE_ORDER.forEach(
            particleId => {

                const currentCount =
                    this.particles.filter(
                        particle =>
                            particle.particleId ===
                            particleId
                    ).length;

                for (
                    let index = currentCount;
                    index < PARTICLES_PER_TYPE;
                    index += 1
                ) {
                    this.particles.push(
                        new FieldParticle(
                            particleId,
                            FIELD_WIDTH,
                            FIELD_HEIGHT
                        )
                    );
                }

            }
        );

    },

    handlePointer(event) {

        if (
            !this.active ||
            this.isActivityCompleted()
        ) {
            return;
        }

        event.preventDefault?.();

        const rectangle =
            this.canvasElement
                .getBoundingClientRect();

        if (
            rectangle.width <= 0 ||
            rectangle.height <= 0
        ) {
            return;
        }

        const pointerX =
            (
                event.clientX -
                rectangle.left
            ) *
            (
                this.canvasElement.width /
                rectangle.width
            );

        const pointerY =
            (
                event.clientY -
                rectangle.top
            ) *
            (
                this.canvasElement.height /
                rectangle.height
            );

        const selectedParticle =
            [...this.particles]
                .reverse()
                .find(
                    particle =>
                        particle.contains(
                            pointerX,
                            pointerY
                        )
                );

        if (!selectedParticle) {
            this.onFieldMiss?.();
            return;
        }

        this.selectParticle(
            selectedParticle
        );

    },

    selectParticle(particle) {

        if (!this.active) {
            return {
                accepted: false,
                correct: false,
                reason: "field-inactive"
            };
        }

        const result =
            this.onParticleSelected(
                particle.particleId
            );

        if (result?.correct) {
            this.particles =
                this.particles.filter(
                    candidate =>
                        candidate !== particle
                );
        }

        if (result?.status?.completed) {

            if (
                this.animationFrameId !==
                null
            ) {
                cancelAnimationFrame(
                    this.animationFrameId
                );

                this.animationFrameId = null;
            }

        } else {
            this.ensurePopulation();
        }

        this.drawFrame(
            performance.now?.() ?? 0
        );

        return result;

    },

    selectFirstParticleOfType(
        particleId
    ) {

        const particle =
            this.particles.find(
                candidate =>
                    candidate.particleId ===
                    particleId
            );

        if (!particle) {
            return {
                accepted: false,
                correct: false,
                reason:
                    "particle-not-visible"
            };
        }

        return this.selectParticle(
            particle
        );

    },

    updateParticles() {

        this.particles.forEach(
            particle =>
                particle.update(
                    FIELD_WIDTH,
                    FIELD_HEIGHT
                )
        );

    },

    drawBackground() {

        const context = this.context;

        context.clearRect(
            0,
            0,
            FIELD_WIDTH,
            FIELD_HEIGHT
        );

        context.fillStyle = "#05010a";
        context.fillRect(
            0,
            0,
            FIELD_WIDTH,
            FIELD_HEIGHT
        );

        context.save();
        context.strokeStyle =
            "rgba(114, 215, 255, 0.08)";
        context.lineWidth = 1;

        for (
            let x = 0;
            x <= FIELD_WIDTH;
            x += 40
        ) {
            context.beginPath();
            context.moveTo(x, 0);
            context.lineTo(
                x,
                FIELD_HEIGHT
            );
            context.stroke();
        }

        for (
            let y = 0;
            y <= FIELD_HEIGHT;
            y += 40
        ) {
            context.beginPath();
            context.moveTo(0, y);
            context.lineTo(
                FIELD_WIDTH,
                y
            );
            context.stroke();
        }

        context.restore();

    },

    drawFrame(timestampMs = 0) {

        if (!this.context) {
            return false;
        }

        this.drawBackground();

        if (this.isActivityCompleted()) {
            this.drawCompletionMessage();
            return true;
        }

        this.particles.forEach(
            particle =>
                particle.draw(
                    this.context,
                    timestampMs
                )
        );

        this.context.save();
        this.context.fillStyle =
            "rgba(247, 239, 255, 0.78)";
        this.context.font =
            "12px monospace";
        this.context.textAlign =
            "left";
        this.context.textBaseline =
            "top";
        this.context.fillText(
            "CLICK OR TAP THE PARTICLE THAT MATCHES THE PROMPT",
            14,
            12
        );
        this.context.restore();

        return true;

    },

    drawCompletionMessage() {

        const context = this.context;

        context.save();
        context.fillStyle =
            "rgba(4, 16, 24, 0.78)";
        context.fillRect(
            0,
            0,
            FIELD_WIDTH,
            FIELD_HEIGHT
        );

        context.fillStyle = "#72d7ff";
        context.font =
            "bold 26px monospace";
        context.textAlign = "center";
        context.textBaseline = "middle";
        context.fillText(
            "FIELD STABILIZED",
            FIELD_WIDTH / 2,
            FIELD_HEIGHT / 2 - 14
        );

        context.fillStyle = "#d9cbea";
        context.font =
            "14px monospace";
        context.fillText(
            "SUBATOMIC ASSEMBLY COMPLETE",
            FIELD_WIDTH / 2,
            FIELD_HEIGHT / 2 + 22
        );
        context.restore();

    },

    animate(timestampMs) {

        if (!this.active) {
            this.animationFrameId = null;
            return;
        }

        if (this.isActivityCompleted()) {
            this.drawFrame(timestampMs);
            this.animationFrameId = null;
            return;
        }

        this.ensurePopulation();
        this.updateParticles();
        this.drawFrame(timestampMs);

        this.animationFrameId =
            requestAnimationFrame(
                nextTimestamp =>
                    this.animate(
                        nextTimestamp
                    )
            );

    },

    activate() {

        if (!this.initialized) {
            return false;
        }

        this.active = true;
        this.ensurePopulation();

        if (this.isActivityCompleted()) {
            this.drawFrame(
                performance.now?.() ?? 0
            );
            return true;
        }

        if (this.animationFrameId === null) {
            this.animationFrameId =
                requestAnimationFrame(
                    timestamp =>
                        this.animate(
                            timestamp
                        )
                );
        }

        console.log(
            "QuantumField.activate() called"
        );

        return true;

    },

    deactivate() {

        this.active = false;

        if (this.animationFrameId !== null) {
            cancelAnimationFrame(
                this.animationFrameId
            );

            this.animationFrameId = null;
        }

        console.log(
            "QuantumField.deactivate() called"
        );

        return true;

    },

    getParticlesSnapshot() {

        return this.particles.map(
            particle => ({
                particleId:
                    particle.particleId,
                x: particle.x,
                y: particle.y,
                radius: particle.radius
            })
        );

    },

    getRuntimeStatus() {

        const counts = {};

        PARTICLE_ORDER.forEach(
            particleId => {
                counts[particleId] =
                    this.particles.filter(
                        particle =>
                            particle.particleId ===
                            particleId
                    ).length;
            }
        );

        return {
            initialized:
                this.initialized,
            active: this.active,
            animationScheduled:
                this.animationFrameId !==
                null,
            completed:
                this.isActivityCompleted(),
            particleCount:
                this.particles.length,
            counts
        };

    },

    destroy() {

        this.deactivate();

        if (
            this.canvasElement &&
            this.pointerHandler
        ) {
            this.canvasElement
                .removeEventListener(
                    "pointerdown",
                    this.pointerHandler
                );
        }

        this.initialized = false;
        this.canvasElement = null;
        this.context = null;
        this.particles = [];
        this.pointerHandler = null;
        this.onParticleSelected = null;
        this.onFieldMiss = null;
        this.getActivityStatus = null;

        return true;

    }

};

export default QuantumField;
