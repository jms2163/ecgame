// --------------------------------------------------
// GameState.js
// Default persisted state for ECGame
// --------------------------------------------------

import CellSystemDefinitions
    from "./CellSystemDefinitions.js";

const gameState = {

    player: {
        id: null,
        name: "",
        displayName: "",
        level: 1,
        xp: 0,
        currentZone: "pond",
        currentZoom: 0
    },

    // --------------------------------------------------
    // Player cell biological systems
    // --------------------------------------------------
    cellSystems:
        CellSystemDefinitions
            .createStartingCellSystems(),

    registry: {

        resources: {
            atp: {
                current: 50,
                maximum: 50
            },

            particles: {
                capacity: 5,
                proton: 0,
                neutron: 0,
                electron: 0,

                lifetimeCollected: {
                    proton: 0,
                    neutron: 0,
                    electron: 0
                }
            }
        },

        inventory: [],

        discoveries: [
            "plasma_membrane",
            "cytoskeleton",
            "glycoproteins"
        ],

        achievements: {},

        research: {
            completedExperiments: {},
            experimentSubmissions: {},
            bestExperimentScores: {},
            stars: {}
        },

        certifications: [],
        quests: {
            q1_particles: {
                status: "in-progress",
                readyAtMs: null,
                claimedAtMs: null
            }
        },
        journal: []

    },

    // --------------------------------------------------
    // Global zones
    //
    // completed means the zone's current required learning
    // milestone is complete. It does not mean the entire
    // scientific subject can never be revisited.
    // --------------------------------------------------
    zones: {

        pond: {
            unlocked: true,
            completed: false,

            state: {
                player: {
                    x: 0,
                    y: 0,
                    anchored: false
                },

                movement: {
                    atpCost: 10
                },

                worldSeed: null,

                world: {
                    tiles: {}
                }
            }
        },

        quantum: {
            // The old progression exposed the Quantum
            // Field at the beginning of Chemical Life.
            unlocked: true,
            completed: false,

            state: {
                audio: {
                    // Quantum sound is independent from
                    // future global or other-zone audio.
                    enabled: true
                },

                upgrades: {
                    // Each future upgrade level removes
                    // 100 ms from the 1500 ms base delay.
                    particleRespawnLevel: 0
                },

                subatomicAssembly: {
                    activityId:
                        "q1_particles",

                    guidedCollected: {
                        proton: 0,
                        neutron: 0,
                        electron: 0
                    },

                    // Generated once at the start of Q1
                    // and persisted so reloads do not
                    // change the current question order.
                    guidedSequence: [],

                    guidanceCompletedAtMs:
                        null,

                    // A wrong particle selection makes
                    // the first guided run ineligible for
                    // its exceptional-work star.
                    incorrectGuidedSelections:
                        0,
                    perfectGuidanceEligible:
                        true
                }
            }
        },

        atomLab: {
            unlocked: false,
            completed: false,
            state: {}
        },

        atomizer: {
            unlocked: false,
            completed: false,
            state: {}
        },

        molecularizer: {
            unlocked: false,
            completed: false,
            state: {}
        },

        macromolecularizer: {
            unlocked: false,
            completed: false,
            state: {}
        },

        polymerizer: {
            unlocked: false,
            completed: false,
            state: {}
        },

        metabolism: {
            unlocked: false,
            completed: false,
            state: {}
        },

        genetics: {
            unlocked: false,
            completed: false,
            state: {}
        }

    },

    settings: {
        volume: 1,
        difficulty: "normal"
    },

    saveVersion: "1.7"

};

export default gameState;
